Closing spaces dashboard
========================

This is the R Shiny app that is shown at https://www.v-dem.net/en/analysis/DemSpace/

Run `StartUp.r` to serve the dashboard prototype in a local browser. 

To update the dashboard with new data, see the 2020 data cleaning R script in the `Data/` folder and copy over the relevant output files from the `create-data` and `modelrunner` folders. 
